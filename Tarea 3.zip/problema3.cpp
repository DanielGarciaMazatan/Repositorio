#include <iostream>
using namespace std;

void main() {

	int n;
	cout << "Ingresa un numero natural: ";
	cin >> n;

	if (n >= 0) {

		int Suma;

		Suma = n * (n + 1) / 2;

		cout << "La suma de los primeros " << n << " numeros naturales es: " << Suma << "." << endl;

	}

	else {

		cout << n << " no es un numero natural." << endl;

	}

	system("pause");
}








