#include <iostream>
using namespace std;

int main()
{
	char nombre[20];
	char apellido[20];
	int edad;
	char telefono[20];

	cout << "Ingrese su nombre:";
	cin >> nombre;

	cout << "Ingrese su apellido:";
	cin >> apellido;

	cout << "Ingrese su edad:";
	cin >> edad;

	cout << "Ingrese su numero telefonico:";
	cin >> telefono;

	cout << "Nombre: " << apellido << ", " << nombre << "." << endl << endl << "Edad: " << edad << " anios." << endl << "Telefono: +52 " << telefono << endl;

	system("pause");

	return 0;
}





















