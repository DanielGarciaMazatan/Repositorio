#include <iostream>
#include <math.h>
using namespace std;

void main(){

	float radio;
	cout << "Ingresa el valor del radio: " << endl;
	cin >> radio;

	float angulo;
	cout << "Ingresa el valor del angulo sexagesimal: " << endl;
	cin >> angulo;

	angulo = angulo * 3.1416 / 180;

	float x = radio * cos(angulo);
	float y = radio * sin(angulo);

	cout << "El punto buscado tiene las coordenadas (" << x << " , " << y << ")." << endl;

	system("pause");
}







